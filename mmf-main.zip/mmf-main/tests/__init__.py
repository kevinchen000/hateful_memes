# Copyright (c) Facebook, Inc. and its affiliates.
from mmf.utils.patch import patch_transformers


patch_transformers()
